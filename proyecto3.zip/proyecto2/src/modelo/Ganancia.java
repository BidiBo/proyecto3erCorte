///*
// * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
// * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
// */
//package modelo;
//
//public class Ganancia {
//    private double costoProduccion  ;
//    private double precioVenta;
//
//    public Ganancia(double costoProduccion, double precioVenta) {
//        this.costoProduccion = costoProduccion;
//        this.precioVenta = precioVenta;
//    }
//
//    public double calcularGanancia() {
//        return precioVenta - costoProduccion;
//    }
//
//    public void setCostoProduccion(double costoProduccion) {
//        this.costoProduccion = costoProduccion;
//    }
//
//    public void setPrecioVenta(double precioVenta) {
//        this.precioVenta = precioVenta;
//    }
//
//    public double getCostoProduccion() {
//        return costoProduccion;
//    }
//
//    public double getPrecioVenta() {
//        return precioVenta;
//    }
//    
//}
